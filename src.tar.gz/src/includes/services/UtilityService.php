<?php
/**
 * <module_context>
 *     <name>UtilityService</name>
 *     <description>Common helper functions for AICliAgents.</description>
 *     <dependencies>LogService</dependencies>
 *     <constraints>Under 150 lines. General purpose utilities.</constraints>
 * </module_context>
 */

namespace AICliAgents\Services;

class UtilityService {
    /**
     * Expand a leading `~` (agent home) in a user-supplied path, like the shell — so a
     * `~/.claude/secrets/prod01.env` clicked in the terminal resolves even when the
     * client didn't expand it (e.g. a stale page that never received window.aicli_home).
     * The home is the agent shells' $HOME = dirname(ConfigService::getUserStatePath()).
     * A non-`~` path is returned unchanged; validation/allowlisting happens downstream.
     */
    public static function expandAgentHome($path) {
        if (!is_string($path)) return $path;
        if ($path === '~' || strncmp($path, '~/', 2) === 0) {
            $home = rtrim(dirname(ConfigService::getUserStatePath()), '/');
            return $path === '~' ? $home : $home . substr($path, 1);
        }
        return $path;
    }

    /**
     * Executes a command in the background, fully detached (#337).
     * $cmd is a shell command line; it runs under `bash -c`.
     */
    public static function execBg($cmd) {
        LogService::log("Spawning background process: $cmd", LogService::LOG_DEBUG, "UtilityService");
        self::spawnDetached(['/bin/bash', '-c', (string)$cmd]);
    }

    /** The shared spawn helper of THIS plugin generation (#337). */
    public static function detachHelperPath(): string {
        return dirname(__DIR__, 2) . '/scripts/aicli-detach.sh';
    }

    /**
     * #337: start a long-lived background process fully detached from this PHP
     * process: a new session, stdin from /dev/null, stdout/stderr to $log, and
     * no inherited descriptor (every fd above 2 is closed). A plain
     * `nohup ... &` keeps every descriptor PHP holds; during `plugin install`
     * one of them is the installer's output pipe, and Unraid's plugin command
     * waits for EOF on it forever. Every PHP spawn site uses this method.
     *
     * @param string[] $argv the command and its arguments (not a shell line)
     * @return int the pid of the started process, or 0 when none was reported
     */
    public static function spawnDetached(array $argv, string $log = '/dev/null', bool $truncate = false): int {
        $args = implode(' ', array_map('escapeshellarg', array_map('strval', $argv)));
        $helper = self::detachHelperPath();
        // R-111: the child must not inherit the workspace id of the request that starts it.
        // A daemon that carried AICLI_SESSION_ID was reaped (by its environment) when that
        // workspace closed. A caller that needs the id sets it on the command itself.
        $unset = 'env -u AICLI_SESSION_ID ';
        if (is_file($helper)) {
            $line = $unset . 'bash ' . escapeshellarg($helper) . ' --log ' . escapeshellarg($log)
                . ($truncate ? ' --truncate' : '') . ' -- ' . $args . ' 2>/dev/null';
        } else {
            // Degraded fallback (helper missing from a broken tree): still a new
            // session and no installer descriptors.
            $line = $unset . 'setsid nohup ' . $args . ' </dev/null ' . ($truncate ? '>' : '>>') . escapeshellarg($log)
                . ' 2>&1 3>&- 4>&- 9>&- & echo $!';
        }
        $out = []; $rc = 0;
        // nosemgrep: php.lang.security.exec-use.exec-use — every argument is escapeshellarg()-quoted
        @exec($line, $out, $rc);
        $pid = trim((string)($out[0] ?? ''));
        return ctype_digit($pid) ? (int)$pid : 0;
    }

    /**
     * Checks if a specific PID is still running on the system.
     */
    public static function isPidRunning($pid) {
        if (empty($pid) || !is_numeric($pid)) return false;
        if (function_exists('posix_kill')) return @posix_kill((int)$pid, 0);
        exec("kill -0 " . escapeshellarg($pid) . " 2>/dev/null", $output, $result);
        return $result === 0;
    }

    /**
     * Sends a GUI notification to the Unraid dashboard.
     */
    public static function notify($message, $subject = "AICliAgents") {
        $msg = escapeshellarg($message);
        $sub = escapeshellarg($subject);
        exec("/usr/local/emhttp/plugins/dynamix/scripts/notify -e \"AICliAgents\" -s $sub -m $msg -i \"tasks\"");
        try { AgentRelayService::publishUnraidNotification((string)$message, (string)$subject); } catch (\Throwable $e) { /* Relay must never block a UI notification. */ }
    }

    /**
     * Returns a list of real Unraid users (excluding system accounts).
     */
    public static function getUnraidUsers() {
        $users = [];
        $passwd = file_get_contents('/etc/passwd');
        if ($passwd) {
            foreach (explode("\n", $passwd) as $line) {
                if (empty($line)) continue;
                $parts = explode(':', $line);
                $uid = (int)$parts[2];
                // Standard Unraid users are usually 1000+ or specifically root
                if ($uid === 0 || ($uid >= 1000 && $uid < 60000)) {
                    $users[] = $parts[0];
                }
            }
        }
        return $users;
    }

    /**
     * Creates a new Unraid user.
     */
    public static function createUser($username, $password, $description = "") {
        if (empty($username) || empty($password)) return ['status' => 'error', 'message' => 'Username/Password required'];
        
        $cmd = "/usr/local/sbin/useradd -m -g users -s /bin/bash -c " . escapeshellarg($description) . " " . escapeshellarg($username);
        exec($cmd, $out, $res);
        if ($res !== 0) return ['status' => 'error', 'message' => 'Failed to create user: ' . implode(" ", $out)];
        
        $passCmd = "echo " . escapeshellarg($username . ":" . $password) . " | chpasswd";
        exec($passCmd, $out, $res);
        if ($res !== 0) return ['status' => 'error', 'message' => 'Failed to set password'];
        
        return ['status' => 'ok'];
    }

    /**
     * Efficiently tails a file.
     */
    public static function tail($file, $lines = 100) {
        if (!file_exists($file)) return [];
        $output = [];
        exec("tail -n " . (int)$lines . " " . escapeshellarg($file) . " 2>&1", $output);
        return $output;
    }

    /**
     * Returns the workspace directory for a user in RAM.
     */
    public static function getWorkDir($user) {
        if (empty($user)) $user = 'root';
        return rtrim(SecretPaths::stateRoot(), '/') . "/work/" . $user;
    }

    /**
     * #549: npm keeps its download cache in ~/.npm. For root on Unraid that is the
     * RAM root disk, and nothing ever emptied it: every agent install, upgrade and
     * version check added to it until the next reboot (1.9 GB on prod02 after one
     * night of agent tests). Each npm call gets its own cache folder from here,
     * and removes it with removeNpmCacheDir() when it ends. A folder that a killed
     * call left behind is removed after a day. AICLI_NPM_CACHE_BASE moves the
     * base folder (tests).
     */
    public static function npmCacheDir(string $tag): string {
        $base = self::npmCacheBase();
        @mkdir($base, 0700, true);
        foreach ((array)@glob($base . '/*', GLOB_ONLYDIR) as $old) {
            if (is_string($old) && @filemtime($old) < time() - 86400) self::removeNpmCacheDir($old);
        }
        $safe = preg_replace('/[^A-Za-z0-9_.-]/', '_', $tag);
        $dir = $base . '/' . $safe . '-' . getmypid() . '-' . bin2hex(random_bytes(4));
        @mkdir($dir, 0700, true);
        return $dir;
    }

    /** Removes a folder that npmCacheDir() gave; refuses any other path. */
    public static function removeNpmCacheDir(string $dir): void {
        $base = self::npmCacheBase();
        $real = realpath($dir);
        if ($real === false || strpos($real, rtrim((string)realpath($base), '/') . '/') !== 0) return;
        exec('rm -rf ' . escapeshellarg($real));
    }

    private static function npmCacheBase(): string {
        $env = getenv('AICLI_NPM_CACHE_BASE');
        return rtrim(is_string($env) && $env !== '' ? $env : SecretPaths::stateRoot() . '/npm-cache', '/');
    }

    /**
     * Executes a command and streams output to a callback (real-time feedback).
     */
    public static function execStreaming($cmd, $callback) {
        $descriptorspec = [
            0 => ["pipe", "r"], // stdin
            1 => ["pipe", "w"], // stdout
            2 => ["pipe", "w"]  // stderr
        ];

        $process = proc_open($cmd, $descriptorspec, $pipes);
        if (is_resource($process)) {
            while ($line = fgets($pipes[1])) {
                $callback(trim($line), false);
            }
            while ($line = fgets($pipes[2])) {
                $callback(trim($line), true);
            }
            fclose($pipes[0]);
            fclose($pipes[1]);
            fclose($pipes[2]);
            return proc_close($process);
        }
        return -1;
    }

    /**
     * Clears any existing installation status files for an agent or all agents.
     */
    public static function clearInstallStatus($agentId = '') {
        $dir = SecretPaths::stateRoot();
        if (empty($agentId)) {
            foreach (glob("$dir/install-status*") as $file) {
                @unlink($file);
            }
        } else {
            @unlink("$dir/install-status-$agentId");
        }
    }

    /**
     * Updates the installation status file for frontend polling.
     */
    public static function setInstallStatus($message, $progress, $agentId = '', $reason = '') {
        $dir = SecretPaths::stateRoot();
        if (!is_dir($dir)) @mkdir($dir, 0755, true);
        $file = empty($agentId) ? "$dir/install-status" : "$dir/install-status-$agentId";
        $status = [
            'step' => $message,
            'status_text' => $message,
            'progress' => $progress,
            'completed' => ($progress >= 100),
            'timestamp' => time(),
            'reason' => $reason
        ];
        @file_put_contents($file, json_encode($status));
        // D-402: Publish install progress via Nchan for real-time UI updates
        if (!empty($agentId)) {
            EventBus::publishInstallProgress($agentId, $progress, $message, $reason);
            // T-08 (ACTIVITY_TRAY.md): mirror every install step into the activity
            // registry. This is the single choke point all install/upgrade/emergency
            // steps flow through, so the heartbeat refreshes per step — the legacy
            // install-status file + per-agent Nchan channel are kept unchanged.
            // Convention (matches the frontend pollers): progress<=0 = failure,
            // progress>=100 = completion, anything else = a live step.
            $opId = "install_$agentId";
            // ACTIVITY_TRAY_PLAIN_NOTICES.md R1/R5/R8: the tray gets the agent's
            // display name and plain step words. The install-status file and the
            // Nchan event above keep the raw message for the Store card.
            $title = self::trayInstallTitle(self::trayAgentName((string)$agentId), false);
            if ($progress >= 100) {
                ActivityService::finish($opId, self::trayInstallStep((string)$message));
            } elseif ($progress <= 0) {
                // The raw reason (it can hold a reason code, a PHP path or a stack
                // trace) goes to the log. The tray gets one sentence.
                LogService::log("Install of $agentId failed: $message" . ((string)$reason !== '' ? " — $reason" : ''), LogService::LOG_ERROR, "UtilityService");
                $f = self::trayInstallFailure((string)$message, (string)$reason);
                ActivityService::fail($opId, $f['error'], $f['recovery'], [
                    'type' => 'install', 'label' => $title, 'step' => '',
                ]);
            } else {
                ActivityService::update($opId, [
                    'type'     => 'install',
                    'label'    => $title,
                    'step'     => self::trayInstallStep((string)$message),
                    'progress' => (int)$progress,
                ]);
            }
        }
    }

    /**
     * The agent's display name for a tray title ("Claude Code", not "claude-code").
     * Falls back to the id when the registry has no entry
     * (ACTIVITY_TRAY_PLAIN_NOTICES.md R4).
     */
    public static function trayAgentName(string $agentId): string {
        try {
            $reg = AgentRegistry::getRegistry();
            $n = is_array($reg[$agentId] ?? null) ? trim((string)($reg[$agentId]['name'] ?? '')) : '';
            if ($n !== '') return $n;
        } catch (\Throwable $e) {
        }
        return $agentId;
    }

    /**
     * The tray title of an install row: "Installing Claude Code" or
     * "Upgrading Claude Code to 2.1.4" (ACTIVITY_TRAY_PLAIN_NOTICES.md R1).
     * Pure: no I/O. $version null or empty gives "Upgrading Claude Code".
     */
    public static function trayInstallTitle(string $agentName, bool $isUpgrade, ?string $version = null): string {
        if (!$isUpgrade) return "Installing $agentName";
        $version = $version === null ? '' : trim($version);
        return $version !== '' ? "Upgrading $agentName to $version" : "Upgrading $agentName";
    }

    /**
     * The grey line of an installed upgrade that waits for open workspaces to
     * close before it switches (ACTIVITY_TRAY_PLAIN_NOTICES.md row 12). Pure.
     */
    public static function trayInstalledWaitStep(int $openWorkspaces): string {
        if ($openWorkspaces <= 0) return 'Installed — waiting for the old version to stop before it switches';
        return 'Installed — waiting for ' . $openWorkspaces . ' workspace' . ($openWorkspaces === 1 ? '' : 's')
            . ' to close before it switches';
    }

    /**
     * An install step message, in the plain words the tray shows
     * (ACTIVITY_TRAY_PLAIN_NOTICES.md R8, row 9-11). Pure: no I/O.
     * The message stays raw in the install-status file for the Store card.
     */
    public static function trayInstallStep(string $message): string {
        $m = trim($message);
        if ($m === '') return '';
        $map = [
            // [prefix, words]; the first prefix that matches wins.
            ['Installed — waiting for', null],              // already plain (install-bg.php row 12)
            ['Installation complete', ''],                  // the pill says it
            ['Emergency install complete', ''],
            ['Upgrade starting', 'Starting'],
            ['Starting installation job', 'Starting'],
            ['Starting queued upgrade', 'Starting'],
            ['Starting emergency install', 'Starting'],
            ['Queued — waiting for another agent upgrade', 'Waiting for another agent upgrade to finish'],
            ['Upgrade queued — saving workspace data', 'Saving workspace data first'],
            ['Upgrade queued', null],                       // PendingAgentUpgradeService words, already plain
            ['Backing up current version', 'Backing up the current version'],
            ['Preparing emergency install', 'Preparing storage'],
            ['Preparing storage', 'Preparing storage'],
            ['Storage ready', 'Preparing storage'],
            ['Starting install', 'Preparing the install'],
            ['Resolving release', 'Finding the release'],
            ['Fetching install script', 'Downloading'],
            ['Downloading', 'Downloading'],
            ['Fetching packages', 'Downloading'],
            ['Extracting', 'Unpacking'],
            ['Linking dependencies', 'Installing'],
            ['Installing:', 'Installing'],
            ['Finalizing permissions', 'Setting permissions'],
            ['Setting permissions', 'Setting permissions'],
            ['Baking SquashFS delta', 'Saving the new version'],
            ['Activating upgraded version', 'Switching to the new version'],
        ];
        foreach ($map as [$prefix, $words]) {
            if (stripos($m, $prefix) === 0) return $words === null ? $m : $words;
        }
        if (preg_match('/^Installing .+ to RAM/i', $m)) return 'Installing';
        // "Running install script… 12s · last output line" -> "Running the installer (12 s)"
        if (stripos($m, 'Running install script') === 0) {
            return preg_match('/^Running install script\D*?(\d+)\s*s\b/u', $m, $mm)
                ? "Running the installer ({$mm[1]} s)"
                : 'Running the installer';
        }
        return $m;
    }

    /**
     * The red sentence and the recovery sentence of a failed install
     * (ACTIVITY_TRAY_PLAIN_NOTICES.md R5, rows 11). Pure: no I/O. One plain
     * sentence; no reason code, no PHP path, no stack trace. The detail is in
     * the Debug Console, which the recovery sentence names.
     * @return array{error:string,recovery:?string}
     */
    public static function trayInstallFailure(string $message, string $reason): array {
        $console = 'Details are in the Debug Console.';
        $m = strtolower(trim($message));
        // A caller that already wrote the sentence (install-bg.php fatal path).
        if ($reason !== '' && preg_match('/^(.{1,200}?\.)\s*Details are in the Debug Console\.?$/s', $reason, $mm)) {
            return ['error' => $mm[1], 'recovery' => $console];
        }
        if ($reason !== '' && stripos($reason, 'not enough free space') !== false) {
            return ['error' => 'Not enough free space for the new version; the version in use is kept.',
                    'recovery' => 'Free some space, then try again.'];
        }
        if (strpos($m, 'storage error') === 0) return ['error' => 'The storage for the agent could not be mounted.', 'recovery' => $console];
        if (strpos($m, 'release channel') === 0) return ['error' => 'The version to install could not be chosen.', 'recovery' => $console];
        if (strpos($m, 'no install source') === 0) return ['error' => 'This agent has no install source.', 'recovery' => $console];
        if (strpos($m, 'install failed (bake') === 0) return ['error' => 'The new version could not be saved.', 'recovery' => $console];
        if (strpos($m, 'backup failed') === 0) return ['error' => 'The backup of the current version failed, so the upgrade stopped and the current version is kept.', 'recovery' => $console];
        if (strpos($m, 'emergency install not available') === 0) return ['error' => 'An emergency install is not possible for this agent.', 'recovery' => 'Start the array and try again.'];
        if (strpos($m, 'emergency install failed') === 0) return ['error' => 'The emergency install did not finish.', 'recovery' => $console];
        if (strpos($m, 'fatal error') === 0) return ['error' => 'The installer stopped with an error.', 'recovery' => $console];
        return ['error' => 'The installer did not finish.', 'recovery' => $console];
    }

    /**
     * Updates a generic task status file for maintenance progress.
     */
    public static function setTaskStatus($user, $message, $progress, $reason = '') {
        $dir = SecretPaths::stateRoot();
        if (!is_dir($dir)) @mkdir($dir, 0755, true);
        $file = "$dir/task-status-$user";
        $status = [
            'step' => $message,
            'status_text' => $message,
            'progress' => $progress,
            'completed' => ($progress >= 100),
            'timestamp' => time(),
            'reason' => $reason
        ];
        @file_put_contents($file, json_encode($status));
    }

    /**
     * Path Helpers for Terminal Sessions
     */
    public static function getSockPath($id = 'default') {
        return "/var/run/aicliterm-$id.sock";
    }

    public static function getPidPath($id = 'default') {
        return "/var/run/unraid-aicliagents-$id.pid";
    }

    public static function getChatIdPath($id = 'default') {
        return "/var/run/unraid-aicliagents-$id.chatid";
    }

    public static function getAgentIdPath($id = 'default') {
        return "/var/run/unraid-aicliagents-$id.agentid";
    }

    public static function getWorkDirFilePath($id = 'default') {
        return "/var/run/unraid-aicliagents-$id.workdir";
    }

    public static function getUserIdPath($id = 'default') {
        return "/var/run/unraid-aicliagents-$id.user";
    }
}
